package egypt

import (
	"context"
	"fmt"
	"io"

	"github.com/slotopol/server/game/slot"
)

// Minislot expectation calculation:
// total combinations: 3*3*3 = 27
//
//	x1 = 27-3=24
//	x3 = 1
//	x6 = 1
//	x9 = 1
//
// Em = (24*1 + 1*3 + 1*6 + 1*9)/27 = 42/27 = 1.5555555556
const Em = 42. / 27.

func CalcStat(ctx context.Context, sp *slot.ScanPar) float64 {
	var reels, _ = ReelsMap.FindClosest(sp.MRTP)
	var g = NewGame(sp.Sel)
	var s = slot.NewStatGeneric(sn, 5)

	var calc = func(w io.Writer) float64 {
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var rtp = rtpsym * Em
		fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
		fmt.Fprintf(w, "RTP = %.5g(sym) * %.5g(Em) = %.6f%%\n", rtpsym*100, Em, rtp*100)
		return rtpsym
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, reels, calc)
}
