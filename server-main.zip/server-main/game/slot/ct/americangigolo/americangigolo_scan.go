package americangigolo

import (
	"context"
	"io"

	"github.com/slotopol/server/game/slot"
)

func CalcStat(ctx context.Context, sp *slot.ScanPar) float64 {
	var reels, _ = ReelsMap.FindClosest(sp.MRTP)
	var g = NewGame(sp.Sel)
	var s = slot.NewStatGeneric(sn, 5)

	var calc = func(w io.Writer) (rtp float64) {
		rtp, _ = slot.Parsheet_generic_freegames(w, sp, s, g.Cost(), 1, 12)
		return
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, reels, calc)
}
