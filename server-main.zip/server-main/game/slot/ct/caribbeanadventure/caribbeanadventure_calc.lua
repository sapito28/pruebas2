-- CT Interactive / Caribbean Adventure
-- RTP calculation

-- 1. REEL STRIPS DATA
local REELS = {
	-- luacheck: push ignore 631
	{12, 4, 9, 7, 6, 11, 4, 13, 1, 11, 8, 12, 4, 9, 5, 10, 1, 11, 3, 12, 2, 11, 10, 6, 9, 3, 10, 5, 13, 7, 8, 12, 5, 13, 6, 8, 7, 13, 3},
	{10, 2, 9, 7, 6, 12, 5, 10, 4, 13, 7, 8, 9, 6, 7, 13, 8, 6, 11, 3, 13, 5, 11, 3, 12, 1, 9, 8, 12, 11, 4, 10, 3, 11, 1, 12, 5, 13, 4},
	{6, 7, 8, 13, 3, 11, 7, 6, 8, 11, 2, 10, 4, 12, 1, 13, 11, 5, 9, 3, 12, 5, 9, 4, 11, 6, 7, 9, 12, 8, 10, 5, 13, 3, 10, 1, 12, 4, 13},
	{12, 9, 7, 13, 4, 10, 5, 11, 3, 10, 1, 9, 5, 12, 6, 8, 12, 3, 9, 7, 11, 13, 4, 10, 2, 11, 4, 13, 5, 11, 6, 8, 7, 6, 8, 12, 3, 13, 1},
	{7, 11, 1, 9, 3, 13, 4, 11, 5, 9, 8, 12, 2, 13, 3, 9, 13, 1, 10, 7, 6, 8, 10, 3, 11, 4, 12, 5, 11, 4, 12, 6, 8, 7, 6, 13, 5, 10, 12},
	-- luacheck: pop
}

-- 2. PAYTABLE FOR LINE WINS (indexed by symbol ID)
local PAYTABLE_LINE = {
	[ 1] = {0, 10, 100, 500, 10000}, --  1 wild
	[ 2] = {},                       --  2 scatter
	[ 3] = {0, 2, 25, 100, 1000},    --  3 pirate
	[ 4] = {0, 2, 25, 100, 1000},    --  4 lady
	[ 5] = {0, 2, 25, 100, 1000},    --  5 spyglass
	[ 6] = {0, 0, 15, 75, 500},      --  6 island
	[ 7] = {0, 0, 15, 50, 400},      --  7 parrot
	[ 8] = {0, 0, 15, 50, 400},      --  8 monkey
	[ 9] = {0, 0, 10, 30, 200},      --  9 ace
	[10] = {0, 0, 10, 30, 200},      -- 10 king
	[11] = {0, 0, 5, 20, 150},       -- 11 queen
	[12] = {0, 0, 5, 20, 150},       -- 12 jack
	[13] = {0, 0, 5, 20, 150},       -- 13 ten
}

-- 3. PAYTABLE FOR SCATTER WINS (for 1 selected line bet)
local PAYTABLE_SCAT = {0, 1, 10, 50, 1000}

-- 4. FREE SPINS TABLE
local FREESPIN_SCAT = {0, 0, 10, 10, 10}

-- 5. CONFIGURATION
local sx, sy = 5, 3 -- grid width & height
local wild, scat = 1, 2 -- wild & scatter symbol IDs
local line_min = 2 -- minimum line symbols to win
local scat_min = 2 -- minimum scatters to win
local sel = 10 -- number of selected bet lines

-- Performs full RTP calculation for given reels
local function calculate(reels)
	assert(#reels == sx, "unexpected number of reels")

	-- Get number of total reshuffles and lengths of each reel.
	local N, L = 1, {}
	for i, r in ipairs(reels) do
		N = N * #r
		L[i] = #r
	end

	-- Count symbols occurrences on each reel
	local counts = {}
	for sym_id in pairs(PAYTABLE_LINE) do
		counts[sym_id] = {}
		for i = 1, sx do counts[sym_id][i] = 0 end
	end
	for i, r in ipairs(reels) do
		for _, sym in ipairs(r) do
			counts[sym][i] = counts[sym][i] + 1
		end
	end

	-- Function to calculate expected return from line wins for all symbols
	local function calculate_line_ev()
		local ev_sum = 0
		local w = counts[wild]
		local wpays = PAYTABLE_LINE[wild]

		for sym_id, pays in pairs(PAYTABLE_LINE) do
			if sym_id ~= wild and #pays > 0 then
				local s = counts[sym_id]
				local c = {}
				for i = 1, sx do c[i] = s[i] + w[i] end

				for n = line_min, sx do
					local payout = pays[n]
					if payout > 0 then
						local combs_total = 1
						for i = 1, sx do
							if i <= n then
								combs_total = combs_total * c[i]
							elseif i == n + 1 then
								combs_total = combs_total * (L[i] - c[i])
							else
								combs_total = combs_total * L[i]
							end
						end

						local better_wilds = 0
						local wn_min = nil
						for wn = line_min, n do
							if wpays[wn] >= payout then
								wn_min = wn
								break
							end
						end
						if wn_min then
							local bw = 1
							for i = 1, sx do
								if i <= wn_min then
									bw = bw * w[i]
								elseif i <= n then
									bw = bw * c[i]
								elseif i == n + 1 then
									bw = bw * (L[i] - c[i])
								else
									bw = bw * L[i]
								end
							end
							better_wilds = bw
						end

						ev_sum = ev_sum + (combs_total - better_wilds) * payout
					end
				end
			end
		end

		-- Calculating wilds as a separate symbol
		for n = line_min, sx do
			local payout = wpays[n]
			if payout > 0 then
				-- 1. Count all "clean heads" from wilds of length exactly n
				local wc = 1
				for i = 1, sx do
					if i <= n then wc = wc * w[i]
					elseif i == n + 1 then wc = wc * (L[i] - w[i])
					else wc = wc * L[i] end
				end

				-- 2. Subtract the cases where this line of wilds is intercepted by the S symbol.
				local losses = 0
				if n < sx then
					for sym_id, pays in pairs(PAYTABLE_LINE) do
						if sym_id ~= wild and #pays > 0 then
							local s = counts[sym_id]
							local c = {}
							for i = 1, sx do c[i] = s[i] + w[i] end

							for sn = n + 1, sx do
								if pays[sn] > payout then
									local loss = 1
									for i = 1, sx do
										if i <= n then
											loss = loss * w[i]
										elseif i == n + 1 then
											loss = loss * s[i]
										elseif i <= sn then
											loss = loss * c[i]
										elseif i == sn + 1 then
											loss = loss * (L[i] - c[i])
										else
											loss = loss * L[i]
										end
									end
									losses = losses + loss
								end
							end
						end
					end
				end
				ev_sum = ev_sum + (wc - losses) * payout
			end
		end

		return ev_sum
	end

	-- Function to calculate expected return from scatter wins
	local function calculate_scat_ev()
		local c = counts[scat]
		local ev_sum, fs_sum, fs_num = 0, 0, 0

		-- Using an recursive approach to sum combinations for exactly N scatters
		local function find_scatter_combs(reel_index, scat_sum, current_comb)
			if reel_index > sx then
				if scat_sum >= scat_min then
					ev_sum = ev_sum + current_comb * PAYTABLE_SCAT[scat_sum]
					if FREESPIN_SCAT[scat_sum] > 0 then
						fs_sum = fs_sum + current_comb * FREESPIN_SCAT[scat_sum]
						fs_num = fs_num + current_comb
					end
				end
				return
			end
			-- Step 1: having a scatter on this reel
			find_scatter_combs(reel_index + 1, scat_sum + 1,
				current_comb * c[reel_index] * sy)
			-- Step 2: NOT having a scatter on this reel
			find_scatter_combs(reel_index + 1, scat_sum,
				current_comb * (L[reel_index] - c[reel_index] * sy))
		end
		find_scatter_combs(1, 0, 1) -- Start recursion

		return ev_sum, fs_sum, fs_num
	end

	-- Function to calculate expected return where all symbols are scatters
	local function calculate_bonscat_ev()
		local ev_sum = 0

		for sym_id, pays in pairs(PAYTABLE_LINE) do
			if #pays > 0 then
				local c = counts[sym_id]
				-- Using an recursive approach to sum combinations for exactly N scatters
				local function find_scatter_combs(reel_index, scat_sum, current_comb)
					if reel_index > sx then
						if scat_sum >= line_min then
							ev_sum = ev_sum + current_comb * pays[scat_sum]
						end
						return
					end
					-- Step 1: having a scatter on this reel
					find_scatter_combs(reel_index + 1, scat_sum + 1,
						current_comb * c[reel_index] * sy)
					-- Step 2: NOT having a scatter on this reel
					find_scatter_combs(reel_index + 1, scat_sum,
						current_comb * (L[reel_index] - c[reel_index] * sy))
				end
				find_scatter_combs(1, 0, 1) -- Start recursion
			end
		end

		return ev_sum
	end

	-- Execute calculation
	local rtp_line = calculate_line_ev() / N
	local rtp_bonline = calculate_bonscat_ev() / N / sel
	local ev_sum, fs_sum, fs_num = calculate_scat_ev()
	local rtp_scat = ev_sum / N
	local rtp_bon = rtp_bonline + rtp_scat
	local q = fs_sum / N
	local sq = 1 / (1 - q)
	local rtp_fs = sq * rtp_bon
	local rtp_sym = rtp_line + rtp_scat
	local rtp_total = rtp_sym + q * rtp_fs
	print(string.format("reels lengths [%s], total reshuffles %d", table.concat(L, ", "), N))
	print(string.format("bonus scatters: %.5g(lined) + %.5g(scatter) = %.6f%%",
		rtp_bonline*100, rtp_scat*100, rtp_bon*100))
	print(string.format("symbols: %.5g(lined) + %.5g(scatter) = %.6f%%", rtp_line*100, rtp_scat*100, rtp_sym*100))
	print(string.format("free spins %d, q = %.5g, sq = 1/(1-q) = %.6f", fs_sum, q, sq))
	print(string.format("free games hit rate: 1/%.5g", N/fs_num))
	print(string.format("RTP = %.5g(sym) + %.5g*%.5g(fg) = %.6f%%", rtp_sym*100, q, rtp_fs*100, rtp_total*100))
	return rtp_total
end

if autoscan then
	return calculate
end

calculate(REELS)
