-- NetEnt / Arabian Nights
-- RTP calculation

-- 1. REEL STRIPS DATA
local REELS_BON = {
	-- luacheck: push ignore 631
	{8, 7, 5, 11, 7, 10, 4, 12, 8, 6, 3, 10, 1, 9, 3, 5, 10, 9, 6, 7, 9, 2, 5, 10, 8, 9, 6, 4},
	{3, 8, 9, 2, 10, 9, 7, 6, 11, 4, 10, 5, 8, 3, 10, 7, 9, 5, 6, 1, 9, 10, 4, 12, 7, 5, 8, 6},
	{10, 9, 6, 4, 10, 8, 1, 7, 5, 9, 12, 3, 9, 5, 8, 10, 7, 4, 10, 9, 11, 3, 6, 7, 8, 6, 2, 5},
	{10, 6, 9, 7, 5, 6, 9, 2, 5, 9, 6, 3, 8, 1, 10, 4, 9, 3, 12, 10, 7, 5, 10, 8, 7, 4, 11, 8},
	{5, 9, 1, 10, 8, 7, 3, 5, 2, 11, 8, 9, 5, 4, 10, 9, 6, 3, 12, 4, 7, 6, 10, 9, 8, 7, 6, 10},
	-- luacheck: pop
}
local REELS_REG = {
	-- luacheck: push ignore 631
	{6, 10, 9, 8, 5, 9, 2, 10, 5, 4, 10, 9, 7, 8, 1, 9, 8, 10, 3, 9, 7, 11, 6, 4, 10, 3, 6, 5, 7, 8, 12, 7},
	{8, 9, 5, 6, 10, 3, 9, 11, 5, 4, 10, 9, 7, 8, 9, 7, 2, 10, 7, 8, 4, 10, 3, 5, 7, 1, 6, 8, 9, 6, 10, 12},
	{4, 5, 8, 10, 7, 6, 3, 8, 11, 9, 7, 10, 12, 8, 6, 9, 4, 5, 9, 1, 10, 9, 2, 8, 5, 7, 3, 10, 7, 6, 9, 10},
	{7, 10, 9, 6, 10, 9, 7, 4, 6, 5, 2, 9, 6, 8, 3, 7, 10, 1, 8, 10, 3, 8, 5, 11, 7, 9, 4, 5, 9, 12, 10, 8},
	{7, 2, 5, 6, 10, 9, 3, 5, 8, 6, 4, 9, 7, 1, 9, 3, 8, 12, 7, 10, 9, 7, 10, 11, 8, 5, 10, 4, 6, 9, 8, 10},
	-- luacheck: pop
}

-- 2. PAYTABLE FOR LINE WINS (indexed by symbol ID)
local PAYTABLE_LINE = {
	[ 1] = {0, 2, 25, 125, 2000},     -- knife
	[ 2] = {0, 2, 25, 125, 1000},     -- sneakers
	[ 3] = {0, 2, 10, 75, 500},       -- tent
	[ 4] = {0, 2, 10, 75, 300},       -- drum
	[ 5] = {0, 0, 5, 30, 150},        -- camel
	[ 6] = {0, 0, 5, 30, 150},        -- king
	[ 7] = {0, 0, 5, 20, 125},        -- queen
	[ 8] = {0, 0, 5, 20, 125},        -- jack
	[ 9] = {0, 0, 3, 15, 75},         -- ten
	[10] = {0, 0, 3, 15, 75},         -- nine
	[11] = {0, 10, 200, 2500, 10000}, -- wild
	[12] = {},                        -- scatter
}

-- 3. PAYTABLE FOR SCATTER WINS (for 1 selected line bet)
local PAYTABLE_SCAT = {0, 2, 5, 20, 500}

-- 4. FREE SPINS TABLE
local FREESPIN_SCAT = {0, 0, 15, 15, 15}

-- 5. CONFIGURATION
local sx, sy = 5, 3 -- grid width & height
local wild, scat = 11, 12 -- wild & scatter symbol IDs
local line_min = 2 -- minimum line symbols to win
local scat_min = 2 -- minimum scatters to win
local mw = 2 -- multiplier on wilds
local mfs = 3 -- multiplier on free spins

-- Performs full RTP calculation for given reels
local function calculate(reels_reg, reels_bon)
	assert(#reels_reg == sx, "unexpected number of regular reels")
	assert(#reels_bon == sx, "unexpected number of bonus reels")

	local reels
	local N, L, counts

	-- Reels precalculations
	local function precalculate_reels()
		-- Get number of total reshuffles and lengths of each reel.
		N, L = 1, {}
		for i, r in ipairs(reels) do
			N = N * #r
			L[i] = #r
		end

		-- Count symbols occurrences on each reel
		counts = {}
		for sym_id in pairs(PAYTABLE_LINE) do
			counts[sym_id] = {}
			for i = 1, sx do counts[sym_id][i] = 0 end
		end
		for i, r in ipairs(reels) do
			for _, sym in ipairs(r) do
				counts[sym][i] = counts[sym][i] + 1
			end
		end
	end

	-- Function to calculate expected return from line wins for all symbols
	local function calculate_line_ev()
		local ev_sum = 0
		local w = counts[wild]
		local wpays = PAYTABLE_LINE[wild]

		for sym_id, pays in pairs(PAYTABLE_LINE) do
			if sym_id ~= wild and #pays > 0 then
				local s = counts[sym_id]
				local c = {}
				for i = 1, sx do c[i] = s[i] + w[i] end

				for n = line_min, sx do
					local payout = pays[n]
					if payout > 0 then
						-- Total combinations
						local combs_total = 1
						for i = 1, sx do
							if i <= n then
								combs_total = combs_total * c[i]
							elseif i == n + 1 then
								combs_total = combs_total * (L[i] - c[i])
							else
								combs_total = combs_total * L[i]
							end
						end

						-- Combinations WITHOUT any wilds on reels
						local combs_no_wild = 1
						for i = 1, sx do
							if i <= n then
								combs_no_wild = combs_no_wild * s[i]
							elseif i == n + 1 then
								combs_no_wild = combs_no_wild * (L[i] - c[i])
							else
								combs_no_wild = combs_no_wild * L[i]
							end
						end

						local better_wilds = 0
						local wn_min = nil
						for wn = line_min, n do
							if wpays[wn] >= payout*mw then
								wn_min = wn
								break
							end
						end
						if wn_min then
							local bw = 1
							for i = 1, sx do
								if i <= wn_min then
									bw = bw * w[i]
								elseif i <= n then
									bw = bw * c[i]
								elseif i == n + 1 then
									bw = bw * (L[i] - c[i])
								else
									bw = bw * L[i]
								end
							end
							better_wilds = bw
						end

						local combs_with_wild = combs_total - combs_no_wild - better_wilds
						ev_sum = ev_sum + (combs_no_wild + combs_with_wild * mw) * payout
					end
				end
			end
		end

		-- Calculating wilds as a separate symbol
		for n = line_min, sx do
			local payout = wpays[n]
			if payout > 0 then
				-- 1. Count all "clean heads" from wilds of length exactly n
				local wc = 1
				for i = 1, sx do
					if i <= n then wc = wc * w[i]
					elseif i == n + 1 then wc = wc * (L[i] - w[i])
					else wc = wc * L[i] end
				end

				-- 2. Subtract the cases where this line of wilds is intercepted by the S symbol.
				local losses = 0
				if n < sx then
					for sym_id, pays in pairs(PAYTABLE_LINE) do
						if sym_id ~= wild and #pays > 0 then
							local s = counts[sym_id]
							local c = {}
							for i = 1, sx do c[i] = s[i] + w[i] end

							for sn = n + 1, sx do
								if pays[sn]*mw > payout then
									local loss = 1
									for i = 1, sx do
										if i <= n then
											loss = loss * w[i]
										elseif i == n + 1 then
											loss = loss * s[i]
										elseif i <= sn then
											loss = loss * c[i]
										elseif i == sn + 1 then
											loss = loss * (L[i] - c[i])
										else
											loss = loss * L[i]
										end
									end
									losses = losses + loss
								end
							end
						end
					end
				end
				ev_sum = ev_sum + (wc - losses) * payout
			end
		end

		return ev_sum
	end

	-- Function to calculate expected return from scatter wins
	local function calculate_scat_ev()
		local c = counts[scat]
		local ev_sum, fs_sum, fs_num = 0, 0, 0

		-- Using an recursive approach to sum combinations for exactly N scatters
		local function find_scatter_combs(reel_index, scat_sum, current_comb)
			if reel_index > sx then
				if scat_sum >= scat_min then
					ev_sum = ev_sum + current_comb * PAYTABLE_SCAT[scat_sum]
					if FREESPIN_SCAT[scat_sum] > 0 then
						fs_sum = fs_sum + current_comb * FREESPIN_SCAT[scat_sum]
						fs_num = fs_num + current_comb
					end
				end
				return
			end
			-- Step 1: having a scatter on this reel
			find_scatter_combs(reel_index + 1, scat_sum + 1,
				current_comb * c[reel_index] * sy)
			-- Step 2: NOT having a scatter on this reel
			find_scatter_combs(reel_index + 1, scat_sum,
				current_comb * (L[reel_index] - c[reel_index] * sy))
		end
		find_scatter_combs(1, 0, 1) -- Start recursion

		return ev_sum, fs_sum, fs_num
	end

	-- Execute calculation
	local rtp_fs
	do
		reels = reels_bon
		precalculate_reels()
		local rtp_line = calculate_line_ev() / N
		local ev_sum, fs_sum, fs_num = calculate_scat_ev()
		local rtp_scat = ev_sum / N
		local rtp_sym = rtp_line + rtp_scat
		local q = fs_sum / N
		local sq = 1 / (1 - q)
		rtp_fs = mfs * sq * rtp_sym
		print(string.format("*bonus reels calculations*"))
		print(string.format("reels lengths [%s], total reshuffles %d", table.concat(L, ", "), N))
		print(string.format("symbols: %.5g(lined) + %.5g(scatter) = %.6f%%", rtp_line*100, rtp_scat*100, rtp_sym*100))
		print(string.format("free spins %d, q = %.5g, sq = 1/(1-q) = %.6f", fs_sum, q, sq))
		print(string.format("free games hit rate: 1/%.5g", N/fs_num))
		print(string.format("RTP = %g*sq*rtp(sym) = %g*%.5g*%.5g = %.6f%%", mfs, mfs, sq, rtp_sym*100, rtp_fs*100))
	end
	local rtp_total
	do
		reels = reels_reg
		precalculate_reels()
		local rtp_line = calculate_line_ev() / N
		local ev_sum, fs_sum, fs_num = calculate_scat_ev()
		local rtp_scat = ev_sum / N
		local rtp_sym = rtp_line + rtp_scat
		local q = fs_sum / N
		local sq = 1 / (1 - q)
		rtp_total = rtp_sym + q * rtp_fs
		print(string.format("*regular reels calculations*"))
		print(string.format("reels lengths [%s], total reshuffles %d", table.concat(L, ", "), N))
		print(string.format("symbols: %.5g(lined) + %.5g(scatter) = %.6f%%", rtp_line*100, rtp_scat*100, rtp_sym*100))
		print(string.format("free spins %d, q = %.5g, sq = 1/(1-q) = %.6f", fs_sum, q, sq))
		print(string.format("free games hit rate: 1/%.5g", N/fs_num))
		print(string.format("RTP = %.5g(sym) + %.5g*%.5g(fg) = %.6f%%", rtp_sym*100, q, rtp_fs*100, rtp_total*100))
	end
	return rtp_total
end

if autoscan then
	return calculate
end

calculate(REELS_REG, REELS_BON)
