//go:build !prod || full || netent

package trolls

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed trolls_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "NetEnt", Name: "Trolls", Date: game.Year(2009), LNum: 20},            // see: https://casino.ru/trolls-netent/
		{Prov: "NetEnt", Name: "Excalibur", Date: game.Date(2013, 11, 11), LNum: 20}, // see: https://www.slotsmate.com/software/netent/excalibur
		{Prov: "NetEnt", Name: "Pandora's Box", Date: game.Year(2009), LNum: 20},
		{Prov: "NetEnt", Name: "Wild Witches", Date: game.Year(2010), LNum: 20},
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgseq |
			game.GPfgmult |
			game.GPscat |
			game.GPwild |
			game.GPwmult,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["netent/trolls/reel"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
